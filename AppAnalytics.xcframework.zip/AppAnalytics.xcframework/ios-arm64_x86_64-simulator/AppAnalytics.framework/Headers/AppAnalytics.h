//
//  AppAnalytics.h
//  AppAnalytics
//
//  Created by Вячеслав on 2/9/25.
//

#import <Foundation/Foundation.h>

//! Project version number for AppAnalytics.
FOUNDATION_EXPORT double AppAnalyticsVersionNumber;

//! Project version string for AppAnalytics.
FOUNDATION_EXPORT const unsigned char AppAnalyticsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppAnalytics/PublicHeader.h>


